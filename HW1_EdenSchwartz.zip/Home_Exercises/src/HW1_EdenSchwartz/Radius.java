//Name: Eden Schwartz
//ID: 315685461
//HW1

package HW1_EdenSchwartz;

public interface Radius {

	public boolean radiusCheck(int radius) throws RadiusException;
}
