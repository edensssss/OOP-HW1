//Name: Eden Schwartz
//ID: 315685461
//HW1

package HW1_EdenSchwartz;

@SuppressWarnings("serial")
public class ColorException extends Exception {

	public ColorException() {
        super("Illegal color!");
    }
}
